#include "avl.h"

node* insert(node *root, int key) {
	// TODO: реализовать функцию
	return nullptr;
}

node* remove(node *root, int key) {
	// TODO: реализовать функцию
	return nullptr;
}

bool exists(node *root, int key) {
	// TODO: реализовать функцию
	return false;
}
