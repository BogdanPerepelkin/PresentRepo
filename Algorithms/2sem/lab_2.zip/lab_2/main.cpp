#include <stdio.h>
#include <stdlib.h>
#include <avl.h>
#include <avl.cpp>

int main() {
    node* root = new node();
    insert(root, 1);
    insert(root, 2);
    insert(root, 3);
    return 0;
}

void dump(node* root) {
    if (root->h == 1) {
        fprintf(stdout, root.key
    }


    dump(root->l);

}